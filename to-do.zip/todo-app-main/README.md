# To Do App

ToDo Flutter project built using GetX, sqflite and flutter local notification 

![1](https://user-images.githubusercontent.com/42120995/135728175-01732326-7cb3-49aa-915a-3580076fb0cf.jpg)
![2](https://user-images.githubusercontent.com/42120995/135728183-20a6f4d8-e1b8-4def-beaf-eafbc4f761c8.jpg)
![3](https://user-images.githubusercontent.com/42120995/135728185-a384934a-1037-406f-a7b6-11f5721980a6.jpg)
![4](https://user-images.githubusercontent.com/42120995/135728189-adb5b880-fb5a-4664-bc08-0c917108de7a.jpg)
